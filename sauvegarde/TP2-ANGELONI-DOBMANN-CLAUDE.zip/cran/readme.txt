Cranfield collection

The Cranfield collection comes in two forms: the 1400 collection; and the 200 collection. Only the 1400 version is given here however.

The bits

cran.all - The documents
cran.qry - The queries
cranqrel - The relevance assesments
readme - Some attempt at explanation especially about the relevance judgements
cran.tar.gz - All the bits put together